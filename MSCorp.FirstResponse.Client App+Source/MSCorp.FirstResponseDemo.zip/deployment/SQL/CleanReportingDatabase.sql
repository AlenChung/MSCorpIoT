-- drop the incidentReporting table if it exists

--Drop tables if they exist
DROP TABLE IF EXISTS IncidentCurrent
GO

DROP TABLE IF EXISTS TicketsCurrent
GO

DROP TABLE IF EXISTS OfficerStatus
GO