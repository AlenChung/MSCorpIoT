﻿namespace MSCorp.FirstResponse.Client.Common
{
    public class Constants
    {
        public const string Incident = "incident";
        public const string AnyFacet = "Any";
        public const string MaleFacet = "Male";
        public const string FemaleFacet = "Female";
    }
}
