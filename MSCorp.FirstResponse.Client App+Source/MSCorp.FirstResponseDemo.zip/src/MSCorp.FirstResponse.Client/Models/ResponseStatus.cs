﻿namespace MSCorp.FirstResponse.Client.Models
{
    public enum ResponseStatus
    {
        Available = 1,
        EnRoute = 2,
        Busy = 3
    }
}