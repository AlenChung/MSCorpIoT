﻿namespace MSCorp.FirstResponse.Client.Models
{
    public enum DepartmentType
    {
        None = 0,
        Police = 1,
        Fire = 2,
        Ambulance = 3,
        Responder = 4
    }
}