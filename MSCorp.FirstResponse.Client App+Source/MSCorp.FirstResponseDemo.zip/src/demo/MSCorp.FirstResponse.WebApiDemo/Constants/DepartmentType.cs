﻿namespace MSCorp.FirstResponse.WebApiDemo.Constants
{
    public enum DepartmentType
    {
        Police = 2,
        Fire = 1, 
        Ambulance = 0
    }
}