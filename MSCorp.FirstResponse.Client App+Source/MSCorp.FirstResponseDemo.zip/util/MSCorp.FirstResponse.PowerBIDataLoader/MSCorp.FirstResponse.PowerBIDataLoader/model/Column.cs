namespace MSCorp.FirstResponse.PowerBIDataLoader.model
{
    public class Column
    {
        public string name { get; set; }
        public string dataType { get; set; }
    }
}