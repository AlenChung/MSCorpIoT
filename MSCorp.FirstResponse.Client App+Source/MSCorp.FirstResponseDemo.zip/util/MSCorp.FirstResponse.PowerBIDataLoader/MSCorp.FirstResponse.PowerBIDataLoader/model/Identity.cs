﻿namespace MSCorp.FirstResponse.PowerBIDataLoader.model
{
    public class Identity
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}