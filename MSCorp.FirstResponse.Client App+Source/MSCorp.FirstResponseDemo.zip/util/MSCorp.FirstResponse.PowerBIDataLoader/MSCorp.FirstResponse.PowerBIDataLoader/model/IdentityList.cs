﻿using System.Collections.Generic;

namespace MSCorp.FirstResponse.PowerBIDataLoader.model
{
    public class IdentityList
    {
        public List<Identity> value { get; set; }
    }
}