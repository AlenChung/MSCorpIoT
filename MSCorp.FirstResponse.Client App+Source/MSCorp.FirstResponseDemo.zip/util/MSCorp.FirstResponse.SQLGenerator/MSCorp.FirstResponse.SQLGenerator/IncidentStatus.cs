namespace MSCorp.SQLGenerator.MSCorp.FirstResponse.Client.Models
{
    public enum IncidentStatus
    {
        AwaitingResponders = 1,
        Resolving = 2,
        Resolved = 3
    }
}