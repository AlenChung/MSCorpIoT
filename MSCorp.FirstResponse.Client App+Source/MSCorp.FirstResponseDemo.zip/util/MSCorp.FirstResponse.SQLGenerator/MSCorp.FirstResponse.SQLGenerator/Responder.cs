﻿namespace MSCorp.SQLGenerator
{
    public class Responder
    {
        public int DepartmentType { get; set; }
    }
}